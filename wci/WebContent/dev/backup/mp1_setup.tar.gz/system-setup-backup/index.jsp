<%@ page contentType="text/html;charset=utf-8"%>
<html>
<head>

<meta name="description" content="기업 간 거래(B2B)를 위한 마켓플레이스 엠피원. 안전하고 효율적인 B2B 거래를 위한 금융 솔루션이 디지털 트랜스포메이션을 돕습니다.">
<meta name="robots" content="index, follow">
<meta property="og:title" content="마켓플레이스 엠피원">
<meta property="og:description" content="기업 간 거래(B2B)를 위한 마켓플레이스 엠피원. 안전하고 효율적인 B2B 거래를 위한 금융 솔루션이 디지털 트랜스포메이션을 돕습>니다.">
<meta property="og:url" content="https://www.mp1.co.kr/mp/">
<meta property="og:type" content="website">
<meta property="og:image" content="https://image.mp1.co.kr/mp/bi_launcher.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="마켓플레이스 엠피원">
<meta name="twitter:description" content="기업 간 거래(B2B)를 위한 마켓플레이스 엠피원. 안전하고 효율적인 B2B 거래를 위한 금융 솔루션이 디지털 트랜스포메이션을 돕습니다.">
<meta name="twitter:image" content="https://image.mp1.co.kr/mp/bi_launcher.png">


<script>
var o = function(){
  window.location.href = "https://www.mp1.co.kr/mp/";
}
setTimeout(o, 20);
</script>
</head>
<body style='text-align:center;'>
<a href='/mp/'><img src='//image.mp1.co.kr/mp/bi_launcher.png' style='width:0;height:0;margin-top: 200px;'></a>
</body>
</html>

