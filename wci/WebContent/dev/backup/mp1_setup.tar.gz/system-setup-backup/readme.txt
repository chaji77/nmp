SETUP GUIDE

0. add user

# useradd -m djemals
# passwd djemals

1. tomcat

(1) install
# cd /home/djemals/system-setup-backup/
# tar -xvzf apache-tomcat-9.0.102.tar.gz
# cd /usr/local
# mkdir tomcat
# cd tomcat
# mv /home/djemals/apache-tomcat-9.0.102/ /usr/local/tomcat
 
(2) jdbc
# cd /home/djemals/system-setup-backup/
# cp mssql-jdbc-12.8.1.jre8.jar /usr/local/tomcat/lib/

(3) inject configuration
# cd /home/djemals/system-setup-backup/
# cp server.xml /usr/local/tomcat/conf/
# cp context.xml /usr/local/tomcat/conf/
# cp tomcat-users.xml /usr/local/tomcat/conf/
# cp mp.xml /usr/local/tomcat/conf/Catalina/localhost/
# cp setenv.sh /usr/local/tomcat/bin/

(4) regist tomcat to systemctl
# cp tomcat.service /etc/systemd/system/
# mkdir /usr/local/tomcat/run
# systemctl daemon-reexec
# systemctl daemon-reload
# systemctl enable tomcat
# systemctl list-unit-files

(5) additional files
# cd /home/djemals/system-setup-backup/
# cp favicon.ico /usr/local/tomcat/webapps/ROOT/
# cp googlec20738addbb18443.html /usr/local/tomcat/webapps/ROOT/
# cp index.jsp /usr/local/tomcat/webapps/ROOT/
# cp robots.txt /usr/local/tomcat/webapps/ROOT/
# cp sitemap.xml /usr/local/tomcat/webapps/ROOT/

(6) start
# systemctl start|stop|restart tomcat

2. nginx

# apt install nginx
# cd /etc/nginx/conf.d/
# cp defalut.conf default.conf.20250601
# cd /home/djemals/system-setup-backup/
# cp default.conf /etc/nginx/conf.d/
# cp *.pem /etc/nginx/conf.d/
# vi /etc/nginx/conf.d/default.conf
  -- fix
# nginx -t
# systemctl start|stop|restart nginx

3. sshd

# cd /home/djemals/system-setup-backup/
# cp issue.net /etc/
# cp sshd_config /etc/ssh/
# systemctl ssh restart
# usermod -aG sudo djemals

