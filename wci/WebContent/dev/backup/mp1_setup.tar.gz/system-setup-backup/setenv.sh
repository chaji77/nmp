export CATALINA_OPTS="-Xms4096m -Xmx6144m -XX:MetaspaceSize=512m -XX:MaxMetaspaceSize=1024m"
